# Ubp3_Una-bottiglia-per-tre
Attenzione:
-IDvino è di tipo double: per far funzionare il codice bisogna inserire un valore numerico.
-Per effettuare il test del metodo associaCliente bisogna prima runnare il test del metodo confermaCliente.
-Le informazioni sono salvate su file di testo
-Il codice caricato non presenta nessun file di testo, questi si creeranno automaticamente una volta provato il programma.
